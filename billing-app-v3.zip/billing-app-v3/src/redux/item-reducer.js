export const itemReducer = (state = {items:[], userinfo:[], summary:{}}, action)=>{
    const {type, payload} = action;
    if(type === 'ADD'){
        const items = [...state.items];
        items.push(payload);
        return {...state, items: items};
    }
    else if (type ==='VIEW'){
        console.log('Async Thunk Called... ', action);
        return state;
    }
    else if (type ==='SUMMARY'){

    }
    else{
        return state;
    }
}