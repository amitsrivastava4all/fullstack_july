const LoggerMiddleWare=(store)=>{
    return next=>{  // same as express next so it will reach u to the next action
        return async action=>{ // hand over to the action call from the dispatcher
            console.log('My Logs are ', action);
            const r = await timeTaken();
            //action.payload.result= r;
            console.log('My Logs are !!!!!! ', action);
            const result = next(action); // move to the next
            console.log('My Logs are :::: ', result);
            return result;
        }
    }
}

const timeTaken = ()=>{
    const pr = new Promise((resolve, reject)=>{
        setTimeout(()=>{
            resolve(1000);
        }, 5000);
    });
    return pr;
   
}

export default LoggerMiddleWare;