export const ActionCreator = (operName,fno,sno)=>{
    console.log('Async Action Creator call');
    return dispatch=>{
        // Async Task 
    //    const pr =  fetch(URL);
    //    pr.then(data=>{
    //         dispatch({operName,payload:{data:data}});
    //    })
    // }
   
    return dispatch=>{
       
        setTimeout(()=>{
            console.log("********Timeout Called....");
            dispatch({
                type:operName,
                payload:
                {
                    firstNumber:fno,
                    secondNumber:sno
                }
            });
        },3000);
    }
    
    
}