import { applyMiddleware, combineReducers, createStore } from "redux";
import { itemReducer } from "./item-reducer";
import logger from 'redux-logger'
import LoggerMiddleWare from "./middlewares/mylogger";
import thunk from 'redux-thunk';

export const store = createStore(itemReducer,  
    applyMiddleware(logger,LoggerMiddleWare, thunk));
store.subscribe((state)=>{
    console.log('State Update ', state);
})