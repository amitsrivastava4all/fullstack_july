import React from "react";
import { Resume } from "./containers/Resume";

function App(){
  return (<Resume/>)
  //return (<div><h1>Hi</h1><p>Hello</p></div>);
  //return (<h1>Hello React JS</h1>);
 // return React.createElement("h1",{"id":"myid"},"Hello React JS - Brain Mentors");
 //return React.createElement("h1",{"id":"myid"},"Hello",React.createElement("span",{"style":{"color":"red"}}, "React JS"));
 // return React.createElement("h1", null, "Hi"), React.createElement("p", null, "Hello");
}
export default App;