import { Menu } from "../components/Menu"
import { ProfilePic } from "../components/ProfilePic"
import { Services } from "../components/Services"

export const Resume = ()=>{
    // return (<div className='container'>
    //     <Menu/>
    //     <ProfilePic/>
    // <h1>I am the Container</h1>
    // <Services/>
    // </div>
    // )
    return (
        <div class="container">
            <Menu/>
  <div class="row">
    <div class="col">
      <ProfilePic/>
    </div>
    <div class="col">
      <Services/>
    </div>
    
  </div>
</div>
    )
}