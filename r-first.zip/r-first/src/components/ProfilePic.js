import './ProfilePic.css';
export const ProfilePic = ()=>{
    return (<h1 className='mycolor'> I am the Profile Pic</h1>)
}