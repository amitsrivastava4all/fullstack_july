export const Services = ()=>{
    const myStyle = {
        backgroundColor:'green',
        color:'red'
    };
    return (<h1 style = {myStyle}> I am the Service</h1>)
}