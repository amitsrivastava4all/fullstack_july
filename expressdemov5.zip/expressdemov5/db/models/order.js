const { SchemaTypes } = require('mongoose');
const connection = require('../connection');
const Schema = connection.Schema;
const orderSchema = new Schema({
    'name':{type:SchemaTypes.String, required: true, unique:true},
    'desc':{type:SchemaTypes.String, required:true},
    'qty':{type:SchemaTypes.Number},
    'price':{type:SchemaTypes.Number},
    'date':{type:SchemaTypes.Date, default: new Date()}
});
const OrderModel = connection.model('orders',orderSchema);
module.exports = OrderModel;