const UserModel = require('../models/user');
const encrypt = require('../../utils/encrypt');
module.exports = {
    add(userObject){
        userObject.password = encrypt.hashPassword(userObject.password);
        return UserModel.create(userObject);
    },
    find(userObject, response){
        
        UserModel.findOne({'email':userObject.email},(err,doc)=>{
            if(err){
                response.status(500).json({message:'Some Problem During Login '+err});
            }
            else if(doc && doc.email){
                let dbPassword = doc.password;
                let plainPassword = userObject.password;
                if(encrypt.compareHash(plainPassword, dbPassword)){
                    response.status(200).json({message:'Welcome '+doc.name})
                }
                else{
                    response.status(404).json({message:'Invalid Userid or Password'});
                }
            }
            else{
                // Invalid 
                response.status(404).json({message:'Invalid Userid or Password'});

            }
        })
    },
    update(userObject){
        UserModel.findOneAndUpdate({'email':userObject.email, 'password':userObject.password},{'password':'aaaaaaa'},(err,doc)=>{

        })
       // Change Password
    },
    remove(userObject){
            UserModel.findOneAndRemove({'email':userObject.email},(err)=>{

            })
    }
}