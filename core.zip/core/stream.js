const fs = require('fs');
const bigFilePath ="/Users/amitsrivastava/Desktop/JS-Video.mp4";
const bigCopyFilePath ="/Users/amitsrivastava/Desktop/JS-Video2Copy.mp4";
const stream = fs.createReadStream(bigFilePath);
const wstream = fs.createWriteStream(bigCopyFilePath);

stream.on('open',()=>{
    console.log('Stream is Open');
});
stream.pipe(wstream);
/*
stream.on('data', chunk=>{
    wstream.write(chunk);
    //console.log("Chunk Rec ",chunk);
});*/
stream.on('end',()=>{
    console.log("Data copied... ");
});
stream.on('close', ()=>{
    console.log("Stream Closed...");
})