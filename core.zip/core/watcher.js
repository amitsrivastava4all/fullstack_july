const filePath = "/Users/amitsrivastava/Desktop/score.rtf";
const fs = require('fs');
// fs.watchFile(filePath,(current, prev)=>{
//     console.log('File has been Change ');
//     const result = fs.readFileSync(filePath);
//     console.log(result.toString());
// });
console.log('Prg is Running and Waiting for the Changes....');
fs.watch(__dirname,(eventType, fileName)=>{
    console.log(eventType, fileName);
})