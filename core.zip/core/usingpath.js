const path = require('path');
const fs = require('fs');
//const fullPath = path.join(__dirname,'mycodes/a.js');
//console.log(fullPath);
const fullPath = path.join( 
    path.normalize(__dirname+"/.."),'/calc22/caller.js');
    console.log('File Name ',path.basename(fullPath));
    console.log('File Name without extension ',path.basename(fullPath, '.js'));
    console.log('OS file Sep ', path.sep, 'Delimeter ', path.delimiter);
    console.log(path.extname(fullPath));
    const obj = path.parse(fullPath);
    console.log(obj);
    console.log(fullPath);
    console.log('Convert ',path.format(obj));
    fs.readFile(fullPath, (err, buffer)=>{
        if(err){
            console.log('Error is ', err);
        }
        else{
            console.log('Data is ', buffer.toString());
        }
    })