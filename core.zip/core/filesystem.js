const fs = require('fs');
const filePath = '/Users/amitsrivastava/Documents/nodejs/core/data.txt';
try{
fs.appendFileSync(filePath, 'I am Sync Demo'); // Blocking code
console.log('Append Done...');
}
catch(err){
    console.log('Error ', err);
}
fs.readFile(__filename,(err, buffer)=>{
    if(err){
        console.log('Some Error During File Read ', err);
    }
    else{
        console.log('Content is ', buffer.toString());
    }
})
fs.writeFile(filePath,"gjkdfgjkdf",{encoding:'utf-8'}, err=>{

});
fs.writeFile(filePath,'Hello How are You !', err=>{
    /*fs.appendFile(filePath,'I am Good ', err=>{ // Async Code (Non Blocking Code)
    if(err){
        console.log('Unable to Write File...', err);
    }
    else{
        console.log('File Written...');
    }
});
console.log('End...');