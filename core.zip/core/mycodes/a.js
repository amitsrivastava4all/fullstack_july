alert("Hello JS ");
console.log("hi JS");