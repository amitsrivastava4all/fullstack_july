import React from 'react'
import UserAdd from '../components/UserAdd'
import UserList from '../components/UserList'

const UserCrud = () => {
  return (
    <div className = 'container'>
        <UserAdd/>
        <UserList/>
    </div>
  )
}

export default UserCrud