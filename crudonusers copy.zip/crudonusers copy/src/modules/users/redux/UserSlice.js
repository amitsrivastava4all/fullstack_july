import { createSlice } from "@reduxjs/toolkit";

 const UserSlice = createSlice({
    name:'users',
    initialState:[],
    reducers:{
       addUser(state, action){
            state.push(action.payload);
       } ,
       deleteUser(state, action){

       },
       viewUser(state, action){
            // filter
       },
       updateUser(state, action){

       }
    }
});
export const {addUser, deleteUser, updateUser, viewUser} = UserSlice.actions;
export const userReducers = UserSlice.reducer;