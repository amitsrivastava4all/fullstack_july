import React from 'react'
import { useSelector } from 'react-redux'

const UserList = () => {
    const allUsers = useSelector((state)=>state.users);
    console.log('All Users ', allUsers);
  return (
    <div>
        <table className="table table-striped table-hover">
        <thead>
    <tr className='table-dark'>
    <th scope="col">S.No</th>
      <th scope="col">Email</th>
      <th scope="col">Password</th>
      <th scope="col">Phone</th>
     
    </tr>
  </thead>
  <tbody>
        {allUsers.map((user,index)=>{
            return (<tr key={index}>
              <td>{index+1}</td>
                <td>{user.email}</td>
                <td>{user.password}</td>
                <td>{user.phone}</td>
            </tr>)
        })}
  </tbody>
</table>
    </div>
  )
}

export default UserList