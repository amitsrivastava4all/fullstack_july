import React, { useRef } from 'react'
import { useDispatch } from 'react-redux';
import { addUser } from '../redux/UserSlice';

const UserAdd = () => {
    const email = useRef('');
    const password = useRef('');
    const phone = useRef('');
    const dispatch = useDispatch();
    const addNewUser = ()=>{
        const userObject = {
            'email': email.current.value,
            'password':password.current.value,
            'phone':phone.current.value
        }
        dispatch(addUser(userObject));
    }
  return (
    <>
        <div className='form-group'>
            <label>Email</label>
            <input ref={email} type='text' className='form-control' placeholder='Type Email Here'/>
        </div>
        <div className='form-group'>
            <label>Password</label>
            <input ref={password} type='password' className='form-control' placeholder='Type Password Here'/>
        </div>
        <div className='form-group'>
            <label>Phone</label>
            <input ref={phone} type='text' className='form-control' placeholder='Type Phone Number Here'/>
        </div>
        <br/>
        <button className='btn btn-primary' onClick = {addNewUser}>Add</button>
        <br/>
    </>
  )
}

export default UserAdd