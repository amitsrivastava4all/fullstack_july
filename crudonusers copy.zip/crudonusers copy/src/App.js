import logo from './logo.svg';
import './App.css';
import UserCrud from './modules/users/pages/UserCrud';

function App() {
  return (
    <UserCrud/>
  );
}

export default App;
