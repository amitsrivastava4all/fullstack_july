import {useEffect, useState} from 'react';
import { SearchBox } from '../components/SearchBox';
import { doAjax } from '../utils/api_client';
export const Alexa = ()=>{
    // Prefetch
    // Life Cycle Method
    const URL = process.env.REACT_APP_imageurl;
    console.log('URL is ', URL);
    const [images, setImages] = useState([]);
    const searchNow = (search)=>{
            doAjax(search, callBack);
    }
    const callBack = (imagesArray)=>{
        setImages(imagesArray);
    }
    useEffect(()=>{
        // Component Did Mount 
        // Network Call / Ajax Call
        doAjax('TomAndJerry', callBack);
        
    },[]);
    return (<>
    <h1>Welcome to Alexa</h1>
    <SearchBox search = {searchNow}/>
    <br/>
    <br/>

    {images.map(image=><img src={image}/>)}
    </>);
}