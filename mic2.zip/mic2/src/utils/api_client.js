export const doAjax = (searchValue , callBackFn)=>{
    const URL = process.env.REACT_APP_imageurl;
    const promise = fetch(URL+searchValue+"&limit=5"); // ES 6
        promise.then(response=>{
            console.log("Response ::::  ",response);
            response.json().then(result=>{
                console.log(result.data instanceof Array);
                const imageArr = result.data.map(e=>e.images.original.url);
                callBackFn(imageArr);
                console.log('JSON is ', result);
            }).catch(err=>{
                console.log('Invalid JSON ', err);
            })
        }).catch(err=>{
            console.log('Error in API Call ',err);
        })
}