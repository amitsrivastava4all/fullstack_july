import { useSelector } from "react-redux"

export const ItemTable = ()=>{
   const showItems = (items)=>{
    console.log('Items is ', items);
    return (<table className="table table-striped table-hover">
        <thead>
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Name</th>
      <th scope="col">Price</th>
    
    </tr>
  </thead>
  <tbody>
            {items.map(item=>{
                return <tr key = {item.id}>
                    <td>{item.id}</td><td> {item.name} </td><td>{item.price}</td>
                </tr>
            })}
            </tbody>
  </table>)
   } 
   const items =  useSelector(state=>state.items);
   return (<>
    {items && items.length>0?showItems(items):<p>No Data</p>}
   </>)
}