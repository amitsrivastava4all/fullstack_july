import { combineReducers, createStore } from "redux";
import { itemReducer } from "./item-reducer";
//const rootReducer = combineReducers(itemReducer, userReducer);
export const store = createStore(itemReducer);
store.subscribe((state)=>{
    console.log('State Update ', state);
})