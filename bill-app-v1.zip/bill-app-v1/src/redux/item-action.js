export const itemAction = (name, data)=>{
    return {
        type: name,
        payload: data
    }
}