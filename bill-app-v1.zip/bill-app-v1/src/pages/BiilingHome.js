import { ItemAdd } from "../components/ItemAdd"
import { ItemSummary } from "../components/ItemSummary"
import { ItemTable } from "../components/ItemTable"

export const BillingHome = ()=>{
    return <div className = 'container'>
        <h1 className = 'text-center alert-info'>Billing App</h1>
        <ItemAdd/>
        <ItemTable/>
        <ItemSummary/>
    </div>
}