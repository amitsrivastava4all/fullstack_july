// function add(a,b){
//     return a + b;
// }
// function sub(a,b){
//     return a - b;
// }
// module.exports.adder = add;
// module.exports.subtract = sub;

// const calc = {
//     add(a,b){
//         return a + b;
//     },
//     sub(a,b){
//         return a - b;
//     }
// }
// module.exports = calc;

module.exports = {
    add(a,b){
        return a + b;
    },
    sub(a,b){
        return a - b;
    }
}
