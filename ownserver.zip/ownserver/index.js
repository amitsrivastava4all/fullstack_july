const http = require('http'); 
const fs = require('fs');
const path = require('path');
const serveFiles = (fileName)=>{
    if(fileName!='/favicon.ico'){
    const fullPath = path.join(__dirname, 'public',fileName);
    try{
    const buffer = fs.readFileSync(fullPath);
    return buffer;
    }
    catch(err){
        return err;
    }
    // fs.readFile(filePath, (err, buffer)=>{
    //     if(err){

    //     }
    //     else{

    //     }
    // })
}
}

// N Times
function handleRequestResponse(request, response){
    console.log('Request Rec ', request.url);
    const url = request.url;
    let fileName = '';
    if(url === '/'){
            fileName  = '/index.html';
        
        //response.write('Home Page');
    }
    else{
        fileName = url;
    }
    
    const fileContent = serveFiles(fileName);
    response.write(fileContent?fileContent:"");
    // else if (url == '/login'){
    //     response.write('Login Page');
    // } else if(url =='/register'){
    //     response.write('Register Page');
    // }
    
    // response.writeHead(200,{'Content-Type':'text/html'});
    // response.write('<h1>Hello Client </h1> '); // BUffer
    // response.write('<h2>Hello Client </h2>'); 
    // response.write('<h3>Hello Client </h3>'); 
    response.end();

}
const server= http.createServer(handleRequestResponse);
server.listen(3333,(err)=>{
    if(err){
        console.log('Server Error Occur ', err,);
    }
    else{
        console.log('Server Start ', server.address().port);
    }
})