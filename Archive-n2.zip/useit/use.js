const obj = require("calc22");
console.log(obj.add(1200,200));