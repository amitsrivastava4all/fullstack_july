const caller = require('./index');
console.log(caller.add(10,20));
console.log(caller.sub(200,300));