export const Operation = ({title, opr})=>{
   // console.log('Rec Object ', props);
    const buttonClicked = ()=>{
        //console.log('Button Clicked...');
        //props.opr();
        opr();
    }
    return (<button onClick={buttonClicked} className='btn btn-primary'>{title}</button>);
}