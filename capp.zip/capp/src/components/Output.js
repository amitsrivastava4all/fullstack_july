export const Output = (props)=>{
    return (<h4>Counter is {props.count}</h4>)
}