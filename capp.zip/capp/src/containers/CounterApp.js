import { useState } from "react";
import { Operation } from "../components/Operation";
import { Output } from "../components/Output";

export const CounterApp = ()=>{
    //var counter = 0;
    const [counter, setCounter] = useState(0);
    const plus = ()=>{
        //counter= counter + 1;
        setCounter(counter+1);
        console.log(`I am the Plus ${counter}`);
    }
    const minus = ()=>{
        //counter = counter - 1;
        setCounter(counter-1);
        console.log(`I am the Minus ${counter}`);
    }
    console.log('Counter App Render');
    return (
    <div className='container'>
    <h1 className='alert-info text-center'>Counter App</h1>
    <Operation title="+" opr = {plus}/> &nbsp;
    <Operation title="-" opr = {minus}/>
    <Output count = {counter}/>
    
    </div>);
}