import { CounterApp } from "./containers/CounterApp"

const App  = ()=>{
  return (<CounterApp/>)
}
export default App;