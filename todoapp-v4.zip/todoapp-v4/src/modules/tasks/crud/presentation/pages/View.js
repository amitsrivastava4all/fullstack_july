import { useLocation, useParams } from "react-router-dom";
import { task_context } from "../../provider/task_context";

export const View = (props)=>{
    console.log('Props rec ', props);
    const stateParams  = useLocation();
    const {status} =  useParams();
    console.log('State Param ', stateParams);
    console.log('Status is ', status);
    return (
        <>
    <h1>I am the View- Status is {status}</h1>
    <task_context.Consumer>
        {(data)=>{
            console.log('Data Consume .... ',data);
            return data.tasks.map((task,index)=>{
                return (<p key={index}>{task.id }{task.name} {task.date} {task.color}</p>)
            })
        }}
    </task_context.Consumer>
    </>
    )
}