export const TASK_OPERATIONS = {
    tasks:[],
    addTask(taskObject){
        this.tasks.push(taskObject);
    },
    viewTask(){
        return this.tasks;
    }
}