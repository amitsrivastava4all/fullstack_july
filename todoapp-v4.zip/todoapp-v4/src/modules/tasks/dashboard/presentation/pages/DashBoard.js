import { Route, Routes } from "react-router-dom";
import { AppRoutes } from "../../../../../config/routes/App_routes";
import { Error } from "../../../../../shared/widgets/error";
import { AddTask } from "../../../crud/presentation/pages/Add";
import { Delete } from "../../../crud/presentation/pages/Delete";
import { Search } from "../../../crud/presentation/pages/Search";
import { Summary } from "../../../crud/presentation/pages/Summary";
import { View } from "../../../crud/presentation/pages/View";
import { Header } from "../widgets/Header";
import { Menu } from "../widgets/LeftMenu";

export const DashBoard = ({companyName})=>{
    return (
    <>
    <Header />
    <div className="container-fluid">
    <div className="row">
        <Menu/>
       
    <main className="col-md-9 ms-sm-auto col-lg-10 px-md-4">
        <div className="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
         <AppRoutes/>
        </div>
        </main>
        </div> 
    </div>
    </>);
}