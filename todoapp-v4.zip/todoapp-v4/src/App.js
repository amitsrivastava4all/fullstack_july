import logo from './logo.svg';
import './App.css';
import { DashBoard } from './modules/tasks/dashboard/presentation/pages/DashBoard';
import { task_context } from './modules/tasks/crud/provider/task_context';

function App() {
  const tasks = {'tasks':[]}
  return (
    <div className='container'>
      <task_context.Provider value ={tasks} >
    <DashBoard />
    </task_context.Provider>
    </div>
  );
}

export default App;
