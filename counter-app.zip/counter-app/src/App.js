import logo from './logo.svg';
import './App.css';
import { CounterApp } from './pages/CounterApp';

function App() {
  return (
    <CounterApp/>
  );
}

export default App;
