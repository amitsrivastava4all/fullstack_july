import { useSelector } from "react-redux"

export const Message = ()=>{
    const output = useSelector(state=>state.result);
    return (<h1>Counter is {output}</h1>)
}
/*
import React from "react";
import { connect } from "react-redux";

// }
 class Message extends React.Component{
    
    render(){
        return (<h1>Counter is {this.props.output}</h1>);
    }
}
const mapStateToProps = state =>{
    return {
        output : state.result
    };

}
export default connect(mapStateToProps)(Message);
*/