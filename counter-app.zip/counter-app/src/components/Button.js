import { numberActionCreator } from "../redux/actions/number_action"
import { store } from "../redux/store";

export const Button = ({label})=>{

    const opr = ()=>{
        const type = label ==='+'?"PLUS":"MINUS";
        const action = numberActionCreator(type,5); // Action Create
        store.dispatch(action); // Dispatch --> Action
    }
    return (<button onClick={opr} className="btn btn-primary">{label}</button>)
}