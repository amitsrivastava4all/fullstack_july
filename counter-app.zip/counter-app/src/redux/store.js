import { createStore } from "redux";
import { computeReducer } from "./reducers/compute_reducer";

export const store = createStore(computeReducer);
store.subscribe(state=>{
    console.log('State Updated... ', state);
})