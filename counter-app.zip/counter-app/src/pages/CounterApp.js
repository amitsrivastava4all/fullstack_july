import { Button } from "../components/Button"
import  {Message}  from "../components/Message"

export const CounterApp = ()=>{
    return <div className="container">
            <Message/>
            <br/>
            <Button label="+"/> &nbsp;
            <Button label="-"/>
    </div>
}