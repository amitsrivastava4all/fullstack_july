const fs = require('fs');
const path = require('path');
const DEFAULT_LANG = require('../constants/app_constants').DEFAULT_LANG
module.exports = {
    messageObject : null,
    readMessageFile(){
        const fullPath= path.join(__dirname,DEFAULT_LANG+'.json');
        const buffer = fs.readFileSync(fullPath); // Read the JSON file
        this.messageObject =JSON.parse(buffer.toString()); // Convert JSON into Object
       
    },
    readMessage(key){
        if(this.messageObject==null){
            this.readMessageFile();
        }
        
        
        return this.messageObject[key];

    }
}