const jwt = require('jsonwebtoken');
const obj = {
    SECRET: 'THISISSECRET',
    generateToken(userid){
        const token = jwt.sign({'userid':userid},'THISISSECRET',{
            //algorithm:'RS256',
            expiresIn:'2d'
        });
        console.log('Token ');
        return token;
    },
    decodeToken(tokenId){
        try{
        const decode = jwt.verify(tokenId,'THISISSECRET');
        if(decode && decode.userid){
            console.log(decode.userid);
            return true;
        }
        else{
            console.log("Invalid Token ");
            return false;
        }
    }
    catch(err){
        console.log('Catch Error in Decode::::: ', err);
        return false;
    }
    }

}
// const t = obj.generateToken('amit')
// console.log(t);
// console.log(obj.decodeToken(t));
module.exports = obj;
