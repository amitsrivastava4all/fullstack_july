const { decodeToken } = require("../token");

const tokenVerify = (request, response, next)=>{
    const tokenId = request.headers['authorization']; 
    console.log('Token Rec in Middleware ', tokenId);
     const isVerified = decodeToken(tokenId); 
     if(isVerified){
        next();
     }
     else{
        response.status(401).json({message:'UnAuthorized User'});
     }
}
module.exports = tokenVerify;