const express = require('express');
const route = express.Router();
const userController = require('../controllers/user');
const {LOGIN, REGISTER, CHANGE_PASSWORD} = require('../utils/constants/app_constants').ROUTES
route.post(REGISTER, userController.register);
route.post(LOGIN, userController.login);
module.exports = route;