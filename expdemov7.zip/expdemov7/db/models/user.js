const { SchemaTypes } = require('mongoose');
const connection = require('../connection');
const Schema = connection.Schema;
const userSchema = new Schema({
    'email':{type:SchemaTypes.String, required: true, unique:true},
    'password':{type:SchemaTypes.String, required:true},
    'name':{type:SchemaTypes.String},
     'carts':[{name:{type:SchemaTypes.String, price:{type:SchemaTypes.Number}}}],   
    'orderid':{type:SchemaTypes.ObjectId, ref:'orders'} // Join 
});
const UserModel = connection.model('users',userSchema);
module.exports = UserModel;