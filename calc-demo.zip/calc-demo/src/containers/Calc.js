import { InputButton } from "../components/InputButton";
import { Operation } from "../components/Operation";
import { Output } from "../components/Output";
import {useState} from 'react';
import { Typography } from "@mui/material";

export const Calc = ()=>{
    //var expression = "";
    const [expression , setExpression ]= useState("");
    const takeValue = (val)=>{
        setExpression(expression+val);
        //expression += val; // expression = expression + val;
        console.log('Expression is ',expression);
    }
    const solveExpression = ()=>{
        setExpression(eval(expression));
    }
    return (<div>
        <Typography variant="h1" component="h2">
  Calc App
</Typography>;
        <Output expression = {expression}/>
        <table>
            <tbody>
            <tr>
                <td><InputButton fn={takeValue}  title="9"/></td>
                <td><InputButton fn={takeValue} title="8"/></td>
                <td><InputButton fn={takeValue} title="7"/></td>
                <td><InputButton fn={takeValue} title="+"/></td>
            </tr>
            <tr>
                <td><InputButton fn={takeValue} title="6"/></td>
                <td><InputButton fn={takeValue} title="5"/></td>
                <td><InputButton fn={takeValue} title="4"/></td>
                <td><InputButton fn={takeValue} title="-"/></td>
               
            </tr>
            <tr>
                <td><Operation fn={solveExpression}/></td>
            </tr>
            </tbody>
        </table>
    </div>);
}