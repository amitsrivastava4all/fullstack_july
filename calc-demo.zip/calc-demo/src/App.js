import { Calc } from "./containers/Calc";

const App = ()=>{
  return (<Calc/>);
}
export default App;