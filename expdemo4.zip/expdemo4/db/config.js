module.exports   = {
    URL : 'mongodb+srv://amit:AMIT123456789@cluster0.y6jwf5b.mongodb.net/tododb?retryWrites=true&w=majority' 
    
}