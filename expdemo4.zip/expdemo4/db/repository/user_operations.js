const UserModel = require('../models/user');
module.exports = {
    add(userObject){
        
        return UserModel.create(userObject);
    },
    find(){

    },
    update(){

    },
    remove(){

    }
}