import logo from './logo.svg';
import './App.css';
import { DashBoard } from './modules/tasks/dashboard/presentation/pages/DashBoard';

function App() {
  return (
    <div className='container'>
    <DashBoard />
    </div>
  );
}

export default App;
