export const Delete = ()=>{
    return (<h1>I am the Delete</h1>)
}