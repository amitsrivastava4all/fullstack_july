export const View = (props)=>{
    console.log('Props rec ', props);
    return (<h1>I am the View- Status is {props.match.params.status}</h1>)
}