export const AddTask = (props)=>{
    console.log('Props is ', props);
    const qs = props.location.search;
    const u = new URLSearchParams(qs);
    let flag = "";
    u.forEach(w=>flag = w);
    return (
    <div>
    <h1 className='alert-info'> {flag=='a'?"Add":"Update"} task</h1>
    <div className = 'form-group'>
        <label>Id </label>
        <input type='text' className="form-control" readOnly />
    </div>
    <div className = 'form-group'>
        <label>Name </label>
        <input type='text' className="form-control"  />
    </div>
    <div className = 'form-group'>
        <label>Color </label>
        <input type='color' className="form-control"  />
    </div>
    <div className = 'form-group'>
        <label>Date </label>
        <input type='date' className="form-control"  />
    </div>
    <div className = 'form-group'>
        <label>Importance </label>
        <select className="form-control"  >
            <option>Moderate</option>
            <option>Critical</option>
            </select>
    </div>
    <br/>
    <div className='form-group'>
        <button className='btn btn-primary'>Add a Task</button>
        &nbsp;
        <button className='btn btn-secondary'>Clear All</button>
    </div>
    </div>);
}