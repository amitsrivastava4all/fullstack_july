import {useEffect, useState} from 'react';
import {Link} from 'react-router-dom';
import { API_CLIENT } from '../../../../../shared/services/api_client';
export const Menu = ()=>{
    const [menus, setMenu] = useState([]);
    useEffect(()=>{
        const promise = API_CLIENT.get(process.env.REACT_APP_MENU_URL);
        promise.then(result=>{
            console.log(result );
            setMenu(result.data.menus);
        }).catch(err=>{
            console.log('Menu Error ', err);
        })
    },[]); // Component Did Mount

    const updateURL = (url)=>{
        if(url =='/add'){
          url = url + "?type=a"; // querystring parameter
        }
        else if (url =='/view'){
          url = url + "/C"; // Path parameter
        }
        return url;
        
    }  

    const createMenuItem = (name,url, index)=>{
        //const status = 'C';
        return ( <li key={index} className="nav-item">
            
          <Link to={updateURL(url)}>{name}</Link>
        {/* <a className="nav-link active" aria-current="page" href={url}>
          <span data-feather="home"></span>
          {name}
        </a> */}
      </li>)
    }

    return (
      <nav id="sidebarMenu" className="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
        <div className="position-sticky pt-3">
          <ul className="nav flex-column">
            {menus.map((menu, index)=>createMenuItem(menu.name, menu.url, index))}
            </ul>
            
           
           
            
        
        </div>
      </nav>
  
      

  );
}