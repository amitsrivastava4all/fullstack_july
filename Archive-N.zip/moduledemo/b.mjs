import show, {fn} from './a.mjs';

console.log(fn());
show();
