export const fn = ()=>"Hello Node Js"; // Wrap in object, Destructure during import
const show=()=>console.log("Hi Node JS"); 
export default show; // Goes as it is. (Only Once)