const chalk = require('chalk');
console.log(chalk.red.bold('Hello Node JS'));