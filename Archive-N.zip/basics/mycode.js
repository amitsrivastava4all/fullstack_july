//throw new Error("Some Error !");
console.log(arguments);