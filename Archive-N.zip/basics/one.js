const fs = require('fs');
console.log('Hello Node JS');
//const FILE_PATH = __dirname+"/one.js";
const FILE_PATH = __filename;
//const FILE_PATH = '/Users/amitsrivastava/Documents/nodejs/basics/one.js';
try{
const result = fs.readFileSync(FILE_PATH);
console.log('Result is '+result);
}
catch(err){
    console.log('Error During File Read ', err);
}
/*fs.readFile(FILE_PATH,(error, buffer)=>{
    if(error){
        console.log('Error while reading ', err);
    }
    else{
        console.log('Data is ', buffer.toString());
    }
});*/
console.log('Hi Node JS');
