console.log('Exports ',exports, typeof exports);
console.log(module.exports === exports);



// exports.add = function(){
//     console.log("I am the Add");
// }
// exports.show= function(){
//     console.log("I am the Show");
// }
exports = {
    add(){
        console.log("I am the Add ");
    },
    show(){
        console.log("I am the Show");
    }
}
console.log(module.exports == exports);
console.log('Exports is ',exports);
