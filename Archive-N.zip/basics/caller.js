const obj = require('./exportvsmodule');
console.log('Object is ',obj);
console.log(obj);
obj.add();
obj.show();