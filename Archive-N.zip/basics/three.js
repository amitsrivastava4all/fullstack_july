// const fn = require('./two');
// console.log(fn(10,20));
const obj = require('./two');
console.log(obj);
console.log(obj.add(10,20));
console.log(obj.sub(10,20));
// console.log(obj.adder(10,20));
// console.log(obj.subtract(10,20));
