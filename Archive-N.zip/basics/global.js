
process.on('uncaughtException',(err)=>{
    console.log('Error Occur...',err);
    // SMS, MAIL
});
process.on('exit',()=>{

});

setTimeout(()=>{
console.log('I will run after 3 sec');
clearInterval(t);
},30000);
const t =setInterval(()=>{
    console.log('I Call After Some Interval Every time');
},4000)

//t++;
console.log('Hi');
var e = new Buffer.alloc(100);
console.log(e);
console.log(__dirname);
console.log(__filename);
console.log(process.cwd());
console.log(process.argv);
console.log(process.arch);
console.log(process.memoryUsage());
console.log(process.cpuUsage());
console.log(process.env);

//console.log(process);

