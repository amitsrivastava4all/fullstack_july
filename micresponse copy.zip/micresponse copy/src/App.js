
import './App.css';
import { Alexa } from './pages/Alexa';

function App() {
  return (
    <Alexa/>
  );
}

export default App;
