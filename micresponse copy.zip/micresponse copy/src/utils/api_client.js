/*export const doAjax = (searchValue , callBackFn)=>{
    const URL = process.env.REACT_APP_imageurl;
    const promise = fetch(URL+searchValue+"&limit=5"); // ES 6
        promise.then(response=>{
            console.log("Response ::::  ",response);
            response.json().then(result=>{
                console.log(result.data instanceof Array);
                const imageArr = result.data.map(e=>e.images.original.url);
                callBackFn(imageArr);
                console.log('JSON is ', result);
            }).catch(err=>{
                console.log('Invalid JSON ', err);
            })
        }).catch(err=>{
            console.log('Error in API Call ',err);
        })
}*/
import axios from 'axios';
axios.defaults.baseURL = process.env.REACT_APP_BASE_URL;
// Local Axios
const axios2 = axios.create({
    baseURL:'90.10.100.20'
}); // Axios New Instance
axios2.get('/login');
export const doAjax = (searchValue , callBackFn, methodName='get')=>{
    const URL = process.env.REACT_APP_imageurl;
    const promisesArr = axios.all([
        axios.get(), axios.post(), axios.put()
    ]);

    const promise = axios({
        //maxContentLength:2000,
        //params:{id:2002,name:'abcd'},
        method:methodName, url:URL+searchValue+"&limit=5",
        // timeout:2000
    });
    //const pralue+"&limit=5");
    //const promise = axios.post(url, object); For Post call Login , register, payment
    promise.then(result=>{
        console.log('Result is ',result);
        const imageArr = result.data.data.map(e=>e.images.original.url);
                callBackFn(imageArr);
    }).catch(err=>{
        console.log('Error in API Call ',err);
    })
}