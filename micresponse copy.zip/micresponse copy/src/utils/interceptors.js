import axios from 'axios';
let obj = {};
export function performanceInterceptor(){
 const reqInterceptor = axios.interceptors.request.use(function (config) {
    // Do something before request is sent
    var date = new Date();
    console.log(date);
    return config;
  }, function (error) {
    // Do something with request error
    return Promise.reject(error);
  });

   const resInterceptor = axios.interceptors.response.use(function (config) {
    // Do something after response is sent
    var date = new Date();
    console.log(date);
    return config;
  }, function (error) {
    // Do something with request error
    return Promise.reject(error);
  });
  obj = {reqInterceptor, resInterceptor};
}
setTimeout(()=>{
    axios.interceptors.request.eject(obj.reqInterceptor);
}
, 1000*60*60
)

export default obj;
