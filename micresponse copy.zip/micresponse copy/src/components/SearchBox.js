import { useRef } from "react";

export const SearchBox = ({search})=>{
    const searchBoxRef = useRef('');
    const takeSearchValue =()=>{
        console.log('Take it ', searchBoxRef.current.value);
        search(searchBoxRef.current.value);
    }
    return (<><input ref={searchBoxRef} type='text' placeholder="Type to Search"/>
    <button onClick={takeSearchValue}>Search Now</button>
    </>);
}