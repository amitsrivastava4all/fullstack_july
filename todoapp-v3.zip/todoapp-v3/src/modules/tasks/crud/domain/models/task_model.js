class TaskModel{
    constructor(id, name, color, date, importance){
        this.id = id;
        this.name = name;
        this.color = color;
        this.date = date;
        this.importance = importance;
    }
}
export default TaskModel;