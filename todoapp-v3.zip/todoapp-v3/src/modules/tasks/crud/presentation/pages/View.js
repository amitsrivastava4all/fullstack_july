import { task_context } from "../../provider/task_context";

export const View = (props)=>{
    console.log('Props rec ', props);
    
    return (
        <>
    <h1>I am the View- Status is {props.match.params.status}</h1>
    <task_context.Consumer>
        {(data)=>{
            console.log('Data Consume .... ',data);
            return data.tasks.map((task,index)=>{
                return (<p key={index}>{task.id }{task.name} {task.date} {task.color}</p>)
            })
        }}
    </task_context.Consumer>
    </>
    )
}