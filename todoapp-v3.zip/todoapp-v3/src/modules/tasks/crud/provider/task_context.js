import React from 'react'
export const task_context = React.createContext({tasks:[]});