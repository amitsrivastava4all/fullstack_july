//const http = require('http'); 
const https = require('https');
const fs = require('fs');
const path = require('path');
const urlObj = require('url');
const qs = require('querystring');

const isStaticFile = (url)=>{
    const staticFiles = [".html",".js",".css", ".jpg",".png",".gif"];
    
    const fullPath = path.join(__dirname+"/public/",url);
    const fileExtension = path.extname(fullPath);
    return staticFiles.indexOf(fileExtension)>=0; // true , false
}

const serveFiles = (fileName)=>{
    if(fileName!='/favicon.ico'){
    const fullPath = path.join(__dirname, 'public',fileName);
    try{
    const buffer = fs.readFileSync(fullPath);
    return buffer;
    }
    catch(err){
        return err;
    }
    // fs.readFile(filePath, (err, buffer)=>{
    //     if(err){

    //     }
    //     else{

    //     }
    // })
}
}

// N Times
function handleRequestResponse(request, response){
    console.log('Request Rec ', request.url);
    let url = request.url;
    const method = request.method;
    let fileName = '';
    if(url === '/'){ // For HomePage
            url  = '/index.html';
        
        //response.write('Home Page');
    }
     // For other Pages (.css, .js, .html, .png etc.)
    if(isStaticFile(url)){
        response.write(serveFiles(url));
        response.end();
    }
    else if (url =='/dashboard'){
        response.write('Welcome to the Dashboard');
        response.end();
    }
    else if ((url == '/login') && method =='POST'){
        let postData = '';
        request.on('data',chunk=>{
            postData += chunk;
        })
        request.on('end',()=>{
                console.log('Post Data is ', postData);
                //const obj = qs.parse(postData);
                const obj = new URLSearchParams(postData);

                const userValues = [];
                obj.forEach(e=>{
                    userValues.push(e);
                    console.log(e);
                })
                if(userValues[0] == userValues[1]){
                    response.writeHead(302,{location:'/dashboard'});
                    //response.write('Welcome User '+userValues[0]);
                }
                else{
                    response.write('Invalid Userid or Password');
                }
                response.end();
                
        });
    }
    else if(url =='/register'){

    }
    else if (url =='/order'){

    }
    else if(url.startsWith('/login') && method == 'GET'){
        //console.log(url);
        //response.write('Login....');
        //console.log(urlObj.parse(url, true));
        const obj = urlObj.parse(url, true);
        console.log(obj);
        const {userid, password} = obj.query;
        console.log(userid, password);
        if(userid == password){
            response.write('Welcome User '+userid);
        }
        else{
            response.write('Invalid Userid and password');
        }
        response.end();
    }
    
    
    // const fileContent = serveFiles(fileName);
    // response.write(fileContent?fileContent:"");
    // else if (url == '/login'){
    //     response.write('Login Page');
    // } else if(url =='/register'){
    //     response.write('Register Page');
    // }
    
    // response.writeHead(200,{'Content-Type':'text/html'});
    // response.write('<h1>Hello Client </h1> '); // BUffer
    // response.write('<h2>Hello Client </h2>'); 
    // response.write('<h3>Hello Client </h3>'); 
    //response.end();

}
const httpsOptions = {
    key:fs.readFileSync('./cert/key.pem'),
    cert:fs.readFileSync('./cert/cert.pem')
}

const server= https.createServer(httpsOptions,handleRequestResponse);
server.listen(3333,(err)=>{
    if(err){
        console.log('Server Error Occur ', err,);
    }
    else{
        console.log('Server Start ', server.address().port);
    }
})