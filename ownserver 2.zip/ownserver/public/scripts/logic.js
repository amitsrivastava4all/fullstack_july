function logic(){
    alert("I am the JS Code");
}
logic();