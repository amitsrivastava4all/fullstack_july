const CONSTANTS = {
    ROUTES : {
        LOGIN : '/login',
        REGISTER : '/register',
        CHANGE_PASSWORD:'/change-password'
    },
    STATUS_CODES :{
        SERVER_ERROR : 500,
        RESOURCE_NOT_FOUND : 404, 
        SUCCESS: 200
    },
    DEFAULT_LANG : 'en'
}
module.exports = CONSTANTS;