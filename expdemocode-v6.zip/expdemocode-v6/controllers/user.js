const user_operations = require("../db/repository/user_operations");
const {SUCCESS, SERVER_ERROR} = require('../utils/constants/app_constants').STATUS_CODES;
const messageReader= require('../utils/i18n/message_reader');
module.exports = {
    changePassword(request, response){
        const userObject =request.body;
        console.log('User Object is CTRL ', userObject);
        user_operations.updatePWD(userObject, response);
    },
    login(request, response){
        const userObject = request.body;
        user_operations.find(userObject, response);
    },
    async register(request, response) {
            const userObject = request.body; // JSON Data 
            console.log(userObject);
            const result = await user_operations.add(userObject);
            console.log(result);
            if(result._id){
                response.status(SUCCESS).json({message:messageReader.readMessage("user.register")});
            }
            else{
                response.status(SERVER_ERROR).json({message:messageReader.readMessage('user.registerfail')});
            }
            

    }
}