const order_operations = require("../db/repository/order_operations");
const user_operations = require("../db/repository/user_operations");

const orderController = {
    async bookOrder(request , response){
        const body = request.body;
        try{
        const orderDoc = await order_operations.add(body);
        if(orderDoc && orderDoc._id){
            const doc = await user_operations.updateOrder(body.userid, orderDoc._id);
            const userOrderDoc =  await user_operations.showUserWiseOrder(body.userid, doc, orderDoc._id);
            console.log(userOrderDoc);
            if(userOrderDoc && userOrderDoc._id){
                response.status(200).json({'order-info': userOrderDoc});
            }
            else{
                response.status(404).json({'order-info':userOrderDoc});
            }
        }
        }
        catch(err){
            console.log('Order Book Error ', err);
        }
    }
}
module.exports = orderController;