const express = require('express');
const route = express.Router();
const orderController = require('../controllers/order');
route.post('/book-order',orderController.bookOrder);
module.exports = route;