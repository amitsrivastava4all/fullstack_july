const OrderModel = require('../models/order');


module.exports = {
   
    async add(orderObject){
        const doc = await OrderModel.create(orderObject);
        return doc;
    },
   
}