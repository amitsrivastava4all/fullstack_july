module.exports   = {
    URL : 'mongodb+srv://amit:amit123456@cluster0.y6jwf5b.mongodb.net/tododb?retryWrites=true&w=majority' 
    
}